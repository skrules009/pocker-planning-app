import { Component, OnInit } from '@angular/core';
import { UtilService } from '../common/utils/utils.service';
import { Observable } from 'rxjs';
import { UserStory } from '../models/member.model';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-poker-cards',
  templateUrl: './poker-cards.component.html',
  styleUrls: ['./poker-cards.component.css']
})
export class PokerCardsComponent implements OnInit {

  cardNumber: number[] = []
  vote: number = 0;
  sessionTitle: string = '';
  storyList$!: UserStory[];
  loggedInUser: string | null = '';
  userRole: string = '';
  setimeout: any;
  hasSessionStarted: boolean = false;
  showError: boolean = false;

  constructor(private utilService: UtilService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.loggedInUser = this.route.snapshot.paramMap.get('userName');
    this.userRole = this.utilService.getUserRoleById(this.loggedInUser || '') || '';
    if (!this.loggedInUser) {
        alert('Oops, Please join session again');
        return;
    }
    const session = this.utilService.getSessionDetail();
    this.sessionTitle = session?.title || '';
    this.cardNumber = this.utilService.getCardNumbers(session?.deck || 0);
    this.setimeout = setInterval(()=>{
      this.storyList$ = this.utilService.getUserStories()
    },1000);
    
  }

  voted(voted: number) {
    this.hasSessionStarted = this.utilService.getSessionNotification();
     if (!this.hasSessionStarted) {
        this.showError = !this.hasSessionStarted
        return;
     }
     this.showError = false;
    this.vote = voted;
    if (this.vote) {
       const userList = this.utilService.getUserList();
       userList.forEach(item => {
        if (item.userId === this.loggedInUser) {
          item.vote = this.vote;
          this.utilService.setUserList(userList);
          return;
        }
       });
    }
    console.log(this.vote);
  }

  deleteStory(storyId: string){
    this.storyList$ = this.utilService.deleteStory(storyId);
  }
  selectStory(id:string){
    if(this.storyList$.find(x=>x.id===id)?.status) {
      return;
    }
    this.utilService.pushNotification(id);
  }

  ngOnDestroy(): void {
    clearTimeout(this.setimeout);
  }
  flipCardEmit(event: boolean) {
    if (event) {
      this.vote = 0;
    }

  }
}
