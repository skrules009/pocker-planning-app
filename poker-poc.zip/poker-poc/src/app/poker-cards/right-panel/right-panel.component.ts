import { Component, Input, OnDestroy, OnInit, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { UtilService } from '../../common/utils/utils.service';
import { Member } from 'src/app/models/member.model';

@Component({
  selector: 'app-right-panel',
  templateUrl: './right-panel.component.html',
  styleUrls: ['./right-panel.component.css']
})
export class RightPanelComponent implements OnInit, OnDestroy {
  isSeesionStarted: boolean = false;
  joinedMemberCount: number = 1;
  isFlipedCard: boolean = false;
  inviteURL = window.location.origin + '/invitation?session=1020';
  currentUserRole: string = '';
  setimeout: any;
  membersList$!: Member[] | undefined;
  showError: boolean = false;
  selectedStory: string = '';
  @Input() userRole: string = '';
  @Output() flipCardEmit: EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor(private utilService: UtilService, private router: Router) { 
  }

  ngOnInit(): void {
   this.setimeout = setInterval(()=>{
      this.membersList$ = this.utilService.getUserList();
      this.isFlipedCard = !this.utilService.getSessionNotification();
      this.flipCardEmit.emit(this.isFlipedCard);
    }, 1000)

    
  }
 
  startSession() {
    this.selectedStory = this.utilService.getSelectedStory() || '';
    if (this.selectedStory?.length < 1) {
      this.showError=true;
      return;
    }
    this.showError = false;
    this.isSeesionStarted = true;
    this.utilService.pushSessionNotification(true);
    this.isFlipedCard = false;
    this.joinedMemberCount = this.utilService.getUserCount();
  }
  

  stopVoting() {
    this.isSeesionStarted = false;
    this.isFlipedCard = !this.isFlipedCard;
    this.utilService.pushSessionNotification(false);
  }

  flipCard() {
    this.isFlipedCard = !this.isFlipedCard;
  }
  skipStory() {

  }
  ngOnDestroy(): void {
    clearTimeout(this.setimeout);
  }
  sendInvitation() {
    window.open(this.inviteURL, '_blank');
  }
  destroySession() {
    clearTimeout(this.setimeout);
    this.utilService.cleanAndDestroySession();
    this.router.navigate(['/']);
  }
}
