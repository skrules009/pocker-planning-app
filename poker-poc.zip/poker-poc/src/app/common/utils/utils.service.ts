import { Injectable } from "@angular/core";
import { Member, Session, UserStory } from "src/app/models/member.model";

@Injectable({
    providedIn:'root'
})
export class UtilService {
    constructor(){

    }

    getCardNumbers(number: number){
        let n1 = 1, n2 = 2, nextTerm;
        let res = [];
        for (let i = 1; n1 <= number; i++) {
          res.push(n1);
          nextTerm = n1 + n2;
          n1 = n2;
          n2 = nextTerm;
        }
        return res;
    }

    getUserList() {
        const userList  = localStorage.getItem("users")
        if (userList  != null) {
             return JSON.parse(userList) as Member[];
        }
        return [];
    }
    getUserCount() {
        const userList  = JSON.parse(localStorage.getItem("users") || '') as Member[];
        return userList.length;
    }
    setUserList(users: Member[]) {
        localStorage.setItem('users', JSON.stringify(users));
    }
    getUserStories(): UserStory[] {
        const stories  = localStorage.getItem("stories")
        if (stories  != null) {
             const storiesData = JSON.parse(stories) as UserStory[];
            return storiesData.sort(x=>x.isSelected ? 0 : -1).sort(x=>x.status ? 0 : -1);
        }
        return [];
    }
    setUserStories(storiesData: UserStory[]){
        localStorage.setItem('stories', JSON.stringify(storiesData));
    }
    deleteStory(id:string): UserStory[] {
        const stories  = localStorage.getItem("stories")
        if (stories  != null) {
             const storieList = JSON.parse(stories) as UserStory[];
             this.setUserStories(storieList.filter(x=>x.id!==id));
             return storieList;
        }
        return [];
    }
    getSessionDetail(): Session {
        const session  = localStorage.getItem("session");
        if (session  != null) {
             return JSON.parse(session) as Session;
        }
        return {} as Session;
    }
    setSession(sessionData: Session, isUpdate: boolean = false ) {
        if(!isUpdate){
            const payload = {userId: 'POC' + this.idGenerator(), name: 'Santosh', role: 'admin', vote: 0} as Member;
            this.setUserList([payload])
        }
        localStorage.setItem('session', JSON.stringify({title: sessionData.title, deck: sessionData.deck, isSessionStarted: sessionData.isSessionStarted}));
    }
    cleanUserData() {
        localStorage.clear();
    }
    cleanAndDestroySession() {
        this.cleanUserData();
    }
    idGenerator() {
        return Math.floor(Math.random() * 100);
    }
    getUserIdByRole(role: string){
        const userList  = JSON.parse(localStorage.getItem("users") || '') as Member[];
        return userList.find(x=>x.role === role)?.userId;
    }
    getUserRoleById(userId: string){
        const userList  = JSON.parse(localStorage.getItem("users") || '') as Member[];
        return userList.find(x=>x.userId === userId)?.role;
    }
    pushNotification(id:string) {
        const stories = this.getUserStories();
        stories.forEach(element => {
            if (element.id === id) {
                element.isSelected = true;
            } else {
                element.isSelected = false;
            }
        });
        this.setUserStories(stories);
    }
    getSelectedStory() {
        const stories = this.getUserStories();
        return stories.find(x=>x.isSelected === true)?.id;
    }
    pushSessionNotification(isStarted: boolean) {
        const session = this.getSessionDetail();
        session.isSessionStarted = isStarted;
        
        if (!isStarted) {
            const userStories = this.getUserStories();
            userStories.forEach(item=>{
                if (item.isSelected) {
                    item.status = true;
                    item.isSelected = false;
                }
            });
            this.setUserStories(userStories);
        } else {
            const userList = this.getUserList();
            userList.forEach(item=>{
                item.vote = 0;
            })
             this.setUserList(userList);
        }
        this.setSession(session, true);
    }
    getSessionNotification() {
        const session = this.getSessionDetail();
        return session.isSessionStarted;
    }
}