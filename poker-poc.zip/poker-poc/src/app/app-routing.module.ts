import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PlanningSessionComponent } from './planning-session/planning-session.component';
import { PokerCardsComponent } from './poker-cards/poker-cards.component';
import { PokerDashboardComponent } from './poker-dashboard/poker-dashboard.component';
import { UserStoriesComponent } from './user-stories/user-stories.component';
import { PokerErrorComponent } from './poker-error/poker-error.component';
import { PokerInvitationComponent } from './poker-invitation/poker-invitation.component';
import { AuthGuard } from './common/utils/auth.guard';

const routes: Routes = [
  {path: '', component: PlanningSessionComponent},
  {path: 'poker-board', component: PokerCardsComponent, canActivate: [AuthGuard]}, 
  {path: 'poker-board/:userName', component: PokerCardsComponent, canActivate: [AuthGuard]},
  {path: 'dashboard', component: PokerDashboardComponent},
  {path: 'userstory', component: UserStoriesComponent},
  {path: 'invitation', component: PokerInvitationComponent, canActivate: [AuthGuard]},
  {path: '**', component: PokerErrorComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
