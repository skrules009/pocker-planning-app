import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import {FormsModule} from '@angular/forms';
import {MatInputModule} from '@angular/material/input';
import { PlanningSessionComponent } from './planning-session/planning-session.component';
import { UserStoriesComponent } from './user-stories/user-stories.component';
import { PokerDashboardComponent } from './poker-dashboard/poker-dashboard.component';
import { PokerCardsComponent } from './poker-cards/poker-cards.component';
import { PokerErrorComponent } from './poker-error/poker-error.component';
import { PanningPanelComponent } from './planning-session/panning-panel/panning-panel.component';
import { MatDialogModule } from '@angular/material/dialog';
import { StoryBoardComponent } from './planning-session/story-board/story-board.component';
import { RightPanelComponent } from './poker-cards/right-panel/right-panel.component';
import { CardsComponent } from './poker-cards/cards/cards.component';
import { PokerInvitationComponent } from './poker-invitation/poker-invitation.component';
import { HttpClientModule } from '@angular/common/http';
import {MatCardModule} from '@angular/material/card';
import {MatIconModule} from '@angular/material/icon';

@NgModule({
  declarations: [
    PlanningSessionComponent,
    UserStoriesComponent,
    PokerDashboardComponent,
    PokerCardsComponent,
    PokerErrorComponent,
    PanningPanelComponent,
    StoryBoardComponent,
    RightPanelComponent,
    CardsComponent,
    PokerInvitationComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatSlideToggleModule, 
    MatInputModule, 
    FormsModule, 
    MatDialogModule,
    HttpClientModule,
    MatCardModule,
    MatIconModule
    
  ],
  providers: [],
  bootstrap: [PokerDashboardComponent],
  exports:[MatInputModule, 
    FormsModule]
})
export class AppModule { }

