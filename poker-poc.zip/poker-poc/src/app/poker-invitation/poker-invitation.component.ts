import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Member } from '../models/member.model';
import { UtilService } from '../common/utils/utils.service';

@Component({
  selector: 'app-poker-invitation',
  templateUrl: './poker-invitation.component.html',
  styleUrls: ['./poker-invitation.component.css']
})
export class PokerInvitationComponent implements OnInit {
  memberName: string ='';
  constructor(private router: Router,  private utilService: UtilService) { }

  ngOnInit(): void {
  }
  
  joinSession() {
    const userId = 'POC'+this.utilService.idGenerator();
    const payload = {userId: userId, name: this.memberName, role: 'user', vote: 0} as Member;
    let users = this.utilService.getUserList();
    if (users) {
      users.push(payload)
      this.utilService.setUserList(users);
    }
    // this.http.post('http://localhost:3000/PokerPlanningSession', payload).subscribe();
    this.router.navigate(['/poker-board', {userName: userId}]);
    
  }
}
