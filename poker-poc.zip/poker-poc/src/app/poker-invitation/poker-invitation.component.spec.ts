import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PokerInvitationComponent } from './poker-invitation.component';

describe('PokerInvitationComponent', () => {
  let component: PokerInvitationComponent;
  let fixture: ComponentFixture<PokerInvitationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PokerInvitationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PokerInvitationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
