import { Component, Inject, OnInit } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
} from '@angular/material/dialog';
import { PlanningSessionComponent } from '../planning-session.component';
import { StoryBoardComponent } from '../story-board/story-board.component';
import { Session } from 'src/app/models/member.model';
import { UtilService } from '../../common/utils/utils.service';

@Component({
  selector: 'app-panning-panel',
  templateUrl: './panning-panel.component.html',
  styleUrls: ['./panning-panel.component.css'],
})
export class PanningPanelComponent implements OnInit {
  sessionTitle!: string;
  deck: number = 1;
  constructor(
    public dialogRef: MatDialogRef<PlanningSessionComponent>,
    public dialog: MatDialog,
    private utilService: UtilService
  ) {}

  ngOnInit(): void {}

  onNoClick(): void {
    this.dialogRef.close();
  }

  addStories(): void {
    const session = {
      title: this.sessionTitle,
      deck: this.deck,
      isSessionStarted: false,
    } as Session;
    this.utilService.setSession(session);
    const dialogRef = this.dialog.open(StoryBoardComponent, {
      width: '700px',
      height: '350px',
      data: {},
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log('The dialog was closed');
      // this.animal = result;
    });
    this.onNoClick();
  }
}
