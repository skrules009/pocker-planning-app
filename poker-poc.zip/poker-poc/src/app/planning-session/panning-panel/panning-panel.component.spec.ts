import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PanningPanelComponent } from './panning-panel.component';

describe('PanningPanelComponent', () => {
  let component: PanningPanelComponent;
  let fixture: ComponentFixture<PanningPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PanningPanelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PanningPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
