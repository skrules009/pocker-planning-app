import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { PanningPanelComponent } from '../panning-panel/panning-panel.component';
import { Router } from '@angular/router';
import { UtilService } from 'src/app/common/utils/utils.service';
import { UserStory } from 'src/app/models/member.model';

@Component({
  selector: 'app-story-board',
  templateUrl: './story-board.component.html',
  styleUrls: ['./story-board.component.css']
})
export class StoryBoardComponent implements OnInit {
  userStoryId!: string;
  userStoryContent!: string;
  storiesData: UserStory[] = [];
  constructor(public dialogRef: MatDialogRef<PanningPanelComponent>, 
    private router: Router, private utilService: UtilService) { }

  ngOnInit(): void {
    this.userStoryId = this.getStoryId();
  }

  canceled() {
    this.dialogRef.close();
  }

  addUserStories(isAddMore: boolean = false) {
    this.storiesData.push({id: this.userStoryId, story: this.userStoryContent, status: false, isSelected: false});
    if (isAddMore) {
      this.userStoryId = this.getStoryId();
      this.userStoryContent = '';
    } else {
      this.utilService.setUserStories(this.storiesData);
      this.router.navigate(['/poker-board', {userName: this.utilService.getUserIdByRole('admin')}]);
      this.dialogRef.close();
    }
  }
  getStoryId() {
    return  'feat' + this.utilService.idGenerator();
  }
}
