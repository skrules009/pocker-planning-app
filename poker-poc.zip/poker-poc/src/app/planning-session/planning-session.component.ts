import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import { PanningPanelComponent } from './panning-panel/panning-panel.component';
import { UtilService } from '../common/utils/utils.service';

@Component({
  selector: 'app-planning-session',
  templateUrl: './planning-session.component.html',
  styleUrls: ['./planning-session.component.css']
})
export class PlanningSessionComponent implements OnInit {

  constructor(public dialog: MatDialog, private utilService: UtilService) { }

  ngOnInit(): void {
  }

  addNewSession(): void {
      this.utilService.cleanUserData();
      
      const dialogRef = this.dialog.open(PanningPanelComponent, {
        width:'700px',
        height:'300px',
        data: {},
      });
  
      dialogRef.afterClosed().subscribe(result => {
        console.log('The dialog was closed');
        // this.animal = result;
      });
  }

}
