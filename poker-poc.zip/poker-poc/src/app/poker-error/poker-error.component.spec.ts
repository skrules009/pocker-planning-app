import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PokerErrorComponent } from './poker-error.component';

describe('PokerErrorComponent', () => {
  let component: PokerErrorComponent;
  let fixture: ComponentFixture<PokerErrorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PokerErrorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PokerErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
