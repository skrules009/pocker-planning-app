import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-poker-error',
  templateUrl: './poker-error.component.html',
  styleUrls: ['./poker-error.component.css']
})
export class PokerErrorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
