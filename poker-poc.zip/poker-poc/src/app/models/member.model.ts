export interface Member {
    userId: string;
    name: string;
    role: string;
    vote: number;
}

export interface UserStory {
    id: string;
    story: string;
    status: boolean;
    isSelected: boolean
}
export interface Session {
    title:string;
    deck: number;
    isSessionStarted: boolean;
}