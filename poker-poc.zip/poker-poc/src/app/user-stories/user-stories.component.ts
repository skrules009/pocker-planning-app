import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-user-stories',
  templateUrl: './user-stories.component.html',
  styleUrls: ['./user-stories.component.css']
})
export class UserStoriesComponent implements OnInit {
  @Input() storyId: string = '';
  @Input() storyDescription: string = '';
  @Input() isDelete: boolean = true;
  @Output() deleteStoryData: EventEmitter<string> = new EventEmitter<string>();
  constructor() { }

  ngOnInit(): void {
  }

  deleteStory(storyId: string){
    this.deleteStoryData.emit(storyId);
  }
}
