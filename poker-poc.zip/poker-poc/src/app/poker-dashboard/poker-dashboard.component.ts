import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-poker-dashboard',
  templateUrl: './poker-dashboard.component.html',
  styleUrls: ['./poker-dashboard.component.css']
})
export class PokerDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
