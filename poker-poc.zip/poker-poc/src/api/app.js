// Import necessary libraries
const express = require('express');
const app = express();
const cors = require('cors');
const port = 3000;
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use(cors({
    origin: '*',
    credentials: true,
}));

// Create the getGreeting function
function getGreeting(req, res) {
  const greeting = 'Hello, world!';
  res.send(greeting);
}

// Define the "greetUser" endpoint
app.get('/greet', getGreeting);
var obj = {
    table: []
};
function setSessionInformation(req, res) {
    const fs = require("fs"); 
    const users = require("./db.json"); 
    users.push(req.body);
   
    const str = JSON.stringify(users);
    console.log(str);
    fs.writeFile("db.json", str.toString(), err => { 
        if (err) throw err;  
        console.log("Done writing"); // Success 
    }); 
    res.send("201: Record created");
}

app.post("/PokerPlanningSession",cors(), setSessionInformation)
function getSessionInformation(req, res) {
    const fs = require("fs"); 
    fs.readFile("db.json", function(err, data) { 
    if (err) throw err; 
    const users = JSON.parse(data); 
    res.send(users);
}); 
}
app.get("/PokerPlanningSession", cors(), getSessionInformation)

function setSessionTitle(req, res) {
   
     fs.readFile('db.json', 'utf8', function readFileCallback(err, data){
        if (err){
            console.log(err);
        } else {
        obj = JSON.parse(data); 
        console.log(obj);
        obj.session.push(req);
        json = JSON.stringify(obj.session); 
        fs.writeFile('db.json', json, 'utf8', callback); 
    }});
    res.send("201: Record created");
}
app.post("/SessionTitle", setSessionTitle);
function getSessionTitle(req, res) {
     fs.readFile('db.json', 'utf8', function readFileCallback(err, data){
        if (err){
            console.log(err);
        } else {
        obj.session = JSON.parse(data.session); 
    }});
    res.send(obj.session);
}
app.get("/SessionTitle",cors(), getSessionTitle);
// Start the server
app.listen(port, () => {
  console.log(`API is running on port ${port}`);
});